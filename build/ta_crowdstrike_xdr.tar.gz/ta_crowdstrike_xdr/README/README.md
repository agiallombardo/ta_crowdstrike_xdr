# License

This project is licensed under the [GNU General Public License v3.0](LICENSE.md) [![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)

© 2025 Anthony Giallombardo, NullQu LLC.

## Contact

Created by Anthony Giallombardo - Anthony at NullQu com
