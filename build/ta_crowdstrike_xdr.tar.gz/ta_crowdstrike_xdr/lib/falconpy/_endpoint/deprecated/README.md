![CrowdStrike Falcon](https://raw.githubusercontent.com/CrowdStrike/falconpy/main/docs/asset/cs-logo.png)
# FalconPy - The CrowdStrike Falcon SDK for Python 3
## Endpoint module, deprecated endpoints
This module contains a complete listing of all deprecated endpoints.
Usually endpoints are deprecated here due to naming convention issues.
