![CrowdStrike Falcon](https://raw.githubusercontent.com/CrowdStrike/falconpy/main/docs/asset/cs-logo.png)
# FalconPy - The CrowdStrike Falcon SDK for Python 3
## Payload module
This module contains a collection of helpers for creating and formatting BODY payloads.
